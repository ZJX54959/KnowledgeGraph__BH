# BiLSTM+CRF 命名实体识别模型

本项目实现了基于BiLSTM+CRF的命名实体识别模型，用于从文本中抽取实体，可以作为知识图谱构建的前置步骤。该模型使用双向LSTM进行特征提取，并使用条件随机场(CRF)进行序列标注，以识别文本中的命名实体。

## 项目结构

```
.
├── bilstm_crf_ner.py     # 主模型实现文件
├── run_ner.py            # 交互式运行脚本
├── ner_visualizer.py     # 可视化工具
├── data/                 # 数据目录
│   ├── ner_sample.txt    # CoNLL格式示例数据
│   └── ner_sample.json   # JSON格式示例数据
└── models/               # 模型保存目录
```

## 功能特点

- 支持多种数据格式（CoNLL格式和JSON格式）
- 使用BIOES标注方案（B-开始，I-中间，E-结束，S-单字，O-非实体）
- 支持多种实体类型（PER-人名，ORG-组织，LOC-地点，TIME-时间，DATE-日期，PRO-产品等）
- 提供交互式训练和预测界面
- 支持批量处理文本文件
- 提供可视化工具，直观展示识别结果

## 环境要求

- Python 3.6+
- PyTorch 1.7+
- NumPy
- scikit-learn
- tqdm
- matplotlib (用于可视化)
- seaborn (用于可视化)

## 安装依赖

```bash
pip install torch numpy scikit-learn tqdm matplotlib seaborn pandas
```

## 使用方法

### 1. 直接使用命令行

#### 训练模型

```bash
python bilstm_crf_ner.py train --data_path ./data/ner_sample.txt --model_path ./models/ner_model.pt
```

参数说明：
- `--data_path`: 训练数据路径
- `--model_path`: 模型保存路径
- `--batch_size`: 批次大小，默认32
- `--epochs`: 训练轮数，默认10
- `--lr`: 学习率，默认0.001
- `--embedding_dim`: 嵌入层维度，默认128
- `--hidden_dim`: 隐藏层维度，默认256
- `--num_layers`: LSTM层数，默认2
- `--dropout`: Dropout比例，默认0.1
- `--split_ratio`: 验证集比例，默认0.1
- `--create_sample`: 是否创建示例数据

#### 预测文本

```bash
python bilstm_crf_ner.py predict --text "北京大学位于北京市海淀区" --model_path ./models/ner_model.pt
```

或者批量处理文件：

```bash
python bilstm_crf_ner.py predict --file_path ./data/test.txt --model_path ./models/ner_model.pt
```

### 2. 使用交互式界面

```bash
python run_ner.py
```

这将启动一个交互式界面，您可以选择：
1. 训练模型
2. 预测文本
3. 评估模型

### 3. 使用可视化工具

```bash
python ner_visualizer.py --text "北京大学位于北京市海淀区" --labels "B-ORG I-ORG I-ORG I-ORG O O B-LOC I-LOC I-LOC B-LOC I-LOC I-LOC"
```

或者可视化JSON格式的实体识别结果：

```bash
python ner_visualizer.py --input ./data/test_entities.json --output visualization.html
```

## 数据格式

### CoNLL格式

每行一个字符和标签，句子之间用空行分隔：

```
北 B-ORG
京 I-ORG
大 I-ORG
学 I-ORG
位 O
于 O
北 B-LOC
京 I-LOC
市 I-LOC

李 B-PER
明 I-PER
在 O
清 B-ORG
华 I-ORG
大 I-ORG
学 I-ORG
```

### JSON格式

包含text和labels字段的JSON对象列表：

```json
[
  {
    "text": "北京大学位于北京市",
    "labels": ["B-ORG", "I-ORG", "I-ORG", "I-ORG", "O", "O", "B-LOC", "I-LOC", "I-LOC"]
  },
  {
    "text": "李明在清华大学",
    "labels": ["B-PER", "I-PER", "O", "B-ORG", "I-ORG", "I-ORG", "I-ORG"]
  }
]
```

## 示例

### 训练示例

```bash
python bilstm_crf_ner.py train --data_path ./data/ner_sample.txt --model_path ./models/ner_model.pt --epochs 20 --batch_size 16
```

### 预测示例

```bash
python bilstm_crf_ner.py predict --text "华为公司是一家总部位于广东深圳的世界500强企业" --model_path ./models/ner_model.pt
```

预期输出：
```
识别结果:
  实体: 华为公司, 类型: ORG
  实体: 广东深圳, 类型: LOC
```

## 模型原理

### BiLSTM+CRF模型结构

1. **嵌入层**：将输入的字符转换为密集向量表示
2. **BiLSTM层**：捕获上下文信息，生成特征表示
3. **线性层**：将BiLSTM的输出映射到标签空间
4. **CRF层**：考虑标签之间的依赖关系，解码最优标签序列

### BIOES标注方案

- **B-X**: 实体X的开始
- **I-X**: 实体X的中间
- **E-X**: 实体X的结束
- **S-X**: 单个字符的实体X
- **O**: 非实体

## 性能优化

- 使用预训练的词向量可以提高模型性能
- 增加训练数据量和多样性
- 调整超参数（如学习率、批次大小、隐藏层维度等）
- 使用更复杂的模型架构（如加入CNN层或Transformer层）

## 许可证

MIT