用法：

```shell
python run_ner.py
```

