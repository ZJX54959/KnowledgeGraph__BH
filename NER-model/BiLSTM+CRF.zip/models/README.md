# 命名实体识别模型目录

此目录用于存放训练好的命名实体识别(NER)模型文件。

## 目录结构

训练完成后，此目录将包含以下文件：

- `ner_model.pt`：模型参数文件
- `vocab.pkl`：词汇表文件
- `label_vocab.pkl`：标签映射文件

## 使用方法

### 训练模型

```bash
python bilstm_crf_ner.py train --data_path ./data/ner_data.txt --model_path ./models/ner_model.pt
```

### 使用模型预测

```bash
python bilstm_crf_ner.py predict --text "北京大学位于北京市海淀区" --model_path ./models/ner_model.pt
```

或者批量处理文件：

```bash
python bilstm_crf_ner.py predict --file_path ./data/test.txt --model_path ./models/ner_model.pt
```