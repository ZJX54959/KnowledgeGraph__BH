抽取的百度百科知识图谱页面

用法：python [constructor.py](constructor.py)

效果：[knowledge_graph.json](KnowledgeGraph\knowledge_graph.json) 